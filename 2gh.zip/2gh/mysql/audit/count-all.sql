SELECT 
    COUNT(`auditid`) as `count`
FROM
    `audit`