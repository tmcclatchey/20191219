DELETE FROM
    `audit`
WHERE
    `userId`=:userId