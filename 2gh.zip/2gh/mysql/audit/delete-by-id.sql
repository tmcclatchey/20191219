DELETE FROM
    `audit`
WHERE
    `auditId`=:auditId