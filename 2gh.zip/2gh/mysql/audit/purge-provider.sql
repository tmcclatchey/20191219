DELETE FROM
    `audit`
WHERE
    `providerId`=:providerId