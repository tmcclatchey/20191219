SELECT
    `roleFlags`
FROM
    `role`
WHERE
    `roleId`=:roleId