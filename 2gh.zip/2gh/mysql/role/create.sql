INSERT INTO
    `role`
(
    `roleName`,
    `roleDescription`,
    `roleFlags`,
    `providerId`
)
VALUES
(
    :roleName,
    :roleDescription,
    :roleFlags,
    :providerId
)