SELECT
    COUNT(`roleId`) AS `count`
FROM
    `role`