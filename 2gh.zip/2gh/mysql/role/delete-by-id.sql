DELETE FROM
    `role`
WHERE
    `roleId`=:roleId