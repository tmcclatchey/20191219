DELETE FROM
    `role`
WHERE
    `providerId`=:providerId