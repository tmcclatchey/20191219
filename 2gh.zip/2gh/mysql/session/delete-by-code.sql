DELETE FROM
    `session`
WHERE
    `sessionCode`=:sessionCode