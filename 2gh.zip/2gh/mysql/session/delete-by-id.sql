DELETE FROM
    `session`
WHERE
    `sessionId`=:sessionId