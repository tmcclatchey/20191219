INSERT INTO
    `session`
(
    `sessionCode`,
    `sessionFingerprint`,
    `sessionCreated`,
    `sessionActivity`,
    `sessionData`
)
VALUES
(
    :sessionCode,
    :sessionFingerprint,
    :sessionCreated,
    :sessionActivity,
    :sessionData
)