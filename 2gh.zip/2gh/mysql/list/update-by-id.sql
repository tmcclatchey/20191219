UPDATE
    `list`
SET
    `listName`=:listName,
    `providerId`=:providerId
WHERE
    `listId`=:listId