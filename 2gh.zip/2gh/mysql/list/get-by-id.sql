SELECT
    `listId`,
    `listName`,
    `providerId`
FROM
    `list`
WHERE
    `listId`=:listId