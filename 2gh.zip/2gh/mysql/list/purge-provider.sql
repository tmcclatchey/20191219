DELETE FROM
    `list`
WHERE
    `providerId`=:providerId