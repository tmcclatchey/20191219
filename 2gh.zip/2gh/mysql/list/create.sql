INSERT INTO
    `list`
(
    `listName`,
    `providerId`
)
VALUES
(
    `listName`,
    `providerId`
)