SELECT
    COUNT(`listId`) AS `count`
FROM
    `list`
WHERE
    `listId`=:listId