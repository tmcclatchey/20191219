DELETE FROM
    `list`
WHERE
    `listId`=:listId