INSERT INTO
    `list_item`
(
    `itemName`,
    `itemValue`,
    `listId`
)
VALUES
(
    :itemName,
    :itemValue
    :listId
)