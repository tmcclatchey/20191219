DELETE FROM
    `list_item`
WHERE
    `listId`=:listId