UPDATE
    `list_item`
SET
    `itemName`=:itemName,
    `itemValue`=:itemValue,
    `listId`=:listId
WHERE
    `itemId`=:itemId