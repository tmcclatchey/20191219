DELETE FROM
    `list_item`
WHERE
    `itemId`=:itemId