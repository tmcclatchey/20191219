SELECT
    COUNT(`listId`) AS `count`
FROM
    `list`