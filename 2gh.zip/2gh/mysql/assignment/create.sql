INSERT  INTO
    `assignment`
(
    `userId`,
    `providerId`,
    `roleId`
)
VALUES
(
    :userId,
    :providerId
    :roleId
);