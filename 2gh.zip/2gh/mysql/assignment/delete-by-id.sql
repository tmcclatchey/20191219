DELETE FROM
    `assignment`
WHERE
    `assignmentId`=:assignmentId