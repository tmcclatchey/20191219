UPDATE
    `assignment`
SET
    `roleId`=:roleId
WHERE
    `assignmentId`=:assignmentId