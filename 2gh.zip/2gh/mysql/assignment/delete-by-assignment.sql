DELETE FROM
    `assignment`
WHERE
    `userId`=:userId AND
    `providerId`=:providerId