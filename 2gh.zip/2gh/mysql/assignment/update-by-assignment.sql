UPDATE
    `assignment`
SET
    `roleId`=:roleId
WHERE
    `userId`=:userId AND
    `providerId`=:providerId