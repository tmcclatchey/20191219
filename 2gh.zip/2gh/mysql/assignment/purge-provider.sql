DELETE FROM
    `assignment`
WHERE
    `providerId`=:providerId;