DELETE FROM
    `assignment`
WHERE
    `userId`=:userId;