SELECT
    COUNT(`providerId`) AS `count`
FROM
    `provider`