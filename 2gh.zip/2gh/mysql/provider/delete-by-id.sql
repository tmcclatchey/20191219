DELETE FROM
    `provider`
WHERE
    `providerId`=:providerId