UPDATE
    `provider`
SET
    `providerName`=:providerName,
    `ownerId`=:ownerId
WHERE
    `providerId`=:providerId