SELECT
    `providerId`,
    `providerName`,
    `ownerId`
FROM
    `provider`
WHERE
    `providerId`=:providerId