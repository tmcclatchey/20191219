DELETE FROM
    `provider`
WHERE
    `ownerId`=:ownerId