INSERT INTO
    `provider`
(
    `providerName`,
    `ownerId`
)
VALUES
(
    :providerName,
    :ownerId
)