UPDATE
    `user`
SET
    `userMobileConfirmed`:=userMobileConfirmed
WHERE
    `userId`=:userId