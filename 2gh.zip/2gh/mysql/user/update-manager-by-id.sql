UPDATE
    `user`
SET
    `userManager`=:userManager
WHERE
    `userId`=:userId