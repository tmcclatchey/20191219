UPDATE
    `user`
SET
    `roleId`=:newRole
WHERE
    `roleId`=:oldRole