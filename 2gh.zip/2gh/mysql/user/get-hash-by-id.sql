SELECT
    `userHash`,
FROM 
    `user`
WHERE
    `userId`=:userId