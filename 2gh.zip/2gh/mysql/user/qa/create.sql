INSERT INTO
    `user_qa`
(
    `qaQuestion`,
    `qaHash`,
    `qaAdded`,
    `qaUpdated`,
    `userId`
)
VALUES
(
    :qaQuestion,
    :qaHash,
    :qaAdded,
    :qaUpdated,
    :userId
)