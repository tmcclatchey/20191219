SELECT
    `qaHash`,
FROM
    `user_qa`
WHERE
    `qaId`=:qaId