DELETE FROM
    `user_qa`
WHERE
    `userId`=:userId