UPDATE
    `user_qa`
SET
    `qaHash`=:qaHash,
    `qaUpdated`=:qaUpdated
WHERE
    `qaId`=:qaId