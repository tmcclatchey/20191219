UPDATE
    `user`
SET
    `userLogin`=:userLogin,
    `userName`=:userName
WHERE
    `userId`=:userId