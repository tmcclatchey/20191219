SELECT
    `userName`,
FROM 
    `user`
WHERE
    `userId`=:userId