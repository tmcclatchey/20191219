SELECT
    COUNT(`userId`) AS `count`
FROM
    `user`