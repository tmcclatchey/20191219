UPDATE
    `user`
SET
    `userRole`=:userRole
WHERE
    `userId`=:userId