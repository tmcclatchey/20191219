DELETE FROM
    `user`
WHERE
    `userId`=:userId