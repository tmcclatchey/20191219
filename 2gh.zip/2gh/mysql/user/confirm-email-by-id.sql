UPDATE
    `user`
SET
    `userEmailConfirmed`=:userEmailConfirmed
WHERE
    `userId`=:userId