UPDATE
    `user`
SET
    `managerId`=:newManager
WHERE
    `managerId`=:oldManager