<?php
    final class ObjectHelper
    {
        public static function ToArray($data)
        {
            //return json_decode(json_encode($data, JSON_OBJECT_AS_ARRAY ), true);
        }

        private function __construct() { }
    }
?>